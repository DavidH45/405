// QuestionableCode.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include <cassert>
#include <iostream>
#include <numeric>
#include <set>
#include <vector>

class C
{
    std::set<int> typedefs;
    bool is_type(int type) const
    {
        if (typedefs.find(type) != typedefs.end())
            return is_type(type); // BUG: endless recursion
        return false;
    }
};

class A
{
    int x;
    A(const A& other) {} // BUG: private copy constructor (never used)
};

class MySpecialType
{
public:
    int MyVal = 1;

    void DontThrow() noexcept // BUG: noexcept but throws
    {
        throw "Ha! I threw anyway!";
    }
};

void foo(int** a)
{
    int b = 1;
    *a = &b; // BUG: returning pointer to local stack variable
}

void work_with_arrays(int count)
{
    int buf[10];
    if (count == 1000)
        buf[count] = 0; // BUG: buffer overflow
}

void do_something_useless()
{
    int sum = 0;
    for (auto i = 0; i < 1000; ++i)
    {
        sum += i;
    }
    std::cout << "I summed up " << sum << " as the answer." << std::endl;
}

void vector_test()
{
    std::vector<int> items;
    items.push_back(1);
    items.push_back(2);
    items.push_back(3);
    std::vector<int>::iterator iter;
    for (iter = items.begin(); iter != items.end(); ++iter)
    {
        if (*iter == 2)
        {
            items.erase(iter); // BUG: invalidates iterator
        }
    }
}

int a;
bool my_function()
{
    a = 1 + 2;
    return a; // BUG: returns int as bool
}

struct Token
{
    Token* next() { return nullptr; }
};

int foo(Token* tok)
{
    while (tok); // BUG: empty while loop
    tok = tok->next();
    return 0;
}

int main()
{
    std::vector<int> counts{ 1, 2, 3, 5 };
    int x = 0;
    int y = 0;
    int z = 0;

    std::cout << "Welcome to the Questionable Code Test!" << std::endl;

    //do_something_useless();

    work_with_arrays(10);

    assert(z = 2); // BUG: assignment instead of comparison

    assert(my_function() == 3);

    try
    {
        int x = 5;
        int y = 5;
        int z = 5;
        std::cout << "x + y + z = " << (x + y + z) << std::endl;
    }
    catch (...)
    {
    }

    int* c;
    foo(&c);

    vector_test();

    MySpecialType myobject;
    std::cout << "myobject.MyVal = " << myobject.MyVal << std::endl;
}
